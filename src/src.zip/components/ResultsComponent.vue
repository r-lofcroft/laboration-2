<template>
    <div>
        <h2>Search Results:</h2>
        <p>{{searchResults}}</p>
    </div>
</template>
<script>
export default {
  name: 'ResultsComponent',
   props:{
        searchResults: {
            type: Array
        }
    }
}
</script>
