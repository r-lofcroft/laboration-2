<template>
  <div id="container">
    <div id="searchBar">
      <img alt="Vue logo" src="../assets/logo.png">
      <Searchbar></Searchbar>
    </div>
    <div id="main">
      <Jumbotron></Jumbotron>
    </div>
    <div>
      <ResultsComponent @get-result="onGetResult"></ResultsComponent>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import Searchbar from '@/components/Searchbar.vue'
import Jumbotron from '@/components/Jumbotron.vue'
import ResultsComponent from '@/components/ResultsComponent.vue'

export default {
  name: 'Home',
  components: {
    Searchbar,
    Jumbotron,
    ResultsComponent
  },
  data(){
    return{
      searchResults: []
    }
  },
  methods: {
    onGetResult(searchResults){
      this.searchResults=searchResults
      console.log(this.searchResults)
    }
  }
}
</script>

<style scoped>
#searchBar{
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  align-content: flex-end;
}
img{
  border-radius: 4px;
  padding: 5px;
  width: 150px;
} 
</style>
