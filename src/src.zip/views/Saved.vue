<template>
  <div class="saved">
    <h1>This page is reserved for saved Animes.</h1>
  </div>
</template>
